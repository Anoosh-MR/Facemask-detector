package com.example.facemaskdetection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VIEWCOURSE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewcourse);
    }
}